<?php
namespace DuplicatorPro\Guzzle\Common\Exception;

defined("ABSPATH") or die("");

/**
 * Guzzle exception
 */
interface GuzzleException {}
