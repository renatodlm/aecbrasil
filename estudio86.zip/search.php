<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package estudio86
 */

get_header();
?>

<?php if ( have_posts() ) : ?>

<div class="topo-interna" 
class="parallax-window" data-parallax="scroll" data-position="center top" 
data-image-src="<?php the_post_thumbnail_url('topo-interna'); ?>">
	<div class="container">
		<div class="conteudo">
			<div class="titulo-topo"><?php the_archive_title( '<h1 class="page-title">', '</h1>' ); ?></div>
		</div>
	</div>
	<div class="overlay"></div>
</div>

<div class="artigos-corpo">
	<div class="container">
		<div class="row">
			<?php while ( have_posts() ) : ?>
				<div class="col-6">
					<?php the_post(); ?>
					<?php get_template_part( 'template-parts/content', 'article' ); ?>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
</div>


<?php else : ?>

	<?php get_template_part( 'template-parts/content', 'none' ); ?>

<?php endif; ?>

<?php
get_footer();
