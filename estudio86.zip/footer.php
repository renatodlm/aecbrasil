<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package estudio86
 */

$telefone = get_field('telefone', 'option');
$email = get_field('email', 'option');
$endereco = get_field('endereco', 'option');

?>

<footer id="footer" class="site-footer">
    <div class="top-footer">
        <div class="container">
            <div class="row d-flex align-items-center">
                <div class="col-lg-2 col-md-6 footer-coluna">
                    <?php
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo = wp_get_attachment_image_src($custom_logo_id, 'logo');
                    $logo_alt = get_field('logo_alternativo', 'option');
                    $logo_largura = get_field('logo_largura', 'option');
                    $logo_altura = get_field('logo_altura', 'option');
                    if ($logo_alt) :
                    ?>
                        <a href="<?php echo get_home_url(); ?>"><img style="width:<?php echo $logo_largura . 'px'; ?>;height:<?php echo $logo_altura . 'px'; ?>" src="<?php echo $logo[0]; ?>" alt="<?php bloginfo('name'); ?>" title="<?php bloginfo('name'); ?>" class="logo"></a>
                    <?php
                    elseif (has_custom_logo()) :
                    ?>
                        <a href="<?php echo get_home_url(); ?>"><img style="width:<?php echo $logo_largura . 'px'; ?>;height:<?php echo $logo_altura . 'px'; ?>" src="<?php echo $logo_alt['url']; ?>" alt="<?php bloginfo('name'); ?>" title="<?php bloginfo('name'); ?>" class="logo-alt"></a>
                    <?php
                    else :
                    ?>
                        <a href="<?php echo get_home_url(); ?>"><?php echo get_bloginfo('name'); ?></a>
                    <?php
                    endif;
                    ?>
                </div>
                <div class="col-lg-5 col-md-6 footer-coluna">
                    <h3 class="titulo-footer">Conectando jogadores<br>
                        através do estudo</h3>
                    <div class="metodos-pagamento">
                        <span>Pagamentos:</span>
                        <ul>
                            <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/pagamento.png" alt=""></li>
                            <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/pagamento-1.png" alt=""></li>
                            <li><img src="<?php echo get_template_directory_uri(); ?>/imgs/pagamento-2.png" alt=""></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 offset-md-1 col-md-6 newsletter-footer">
                    <div class="newslleter-footer-container">
                        <h3 class="newslleter-footer-title">
                            Receba nossa newsletter:
                        </h3>
                        <form action="">
                            <div class="d-flex align-items-center">
                                <input type="text" placeholder="Insira seu e-mail"><input type="submit" value="Enviar">
                            </div>
                        </form>
                        <ul>
                            <li>
                                <a href="#"><i class="icon-facebook"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="icon-instagram"></i></a>
                            </li>
                            <li>
                                <a href="#"><i class="icon-youtube"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="menu-footer d-md-flex d-none align-items-center justify-content-between">
                        <?php wp_nav_menu(
                            array(
                                'theme_location'    => 'menu_footer',
                                'depth'             => 2,
                                'menu_id'      => '',
                                'container_id'      => '',
                                'container' => 'ul',
                            )
                        );
                        ?>
                        <ul class="header-login d-inline-flex">
                            <li class="m-0">
                                <button class="btn-login"><i class="header-icon-login"></i>Login</button>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-12">
                    <div class="sub-footer d-flex align-items-center justify-content-md-between justify-content-center">
                        <div class="direitos"><?php bloginfo('name'); ?> © <?php echo date('Y'); ?> - Todos os direitos reservados a Ideas4Apps</div>
                        <div class="menu-institucional"> <?php wp_nav_menu(
                                                                array(
                                                                    'theme_location'    => 'menu_institucional',
                                                                    'depth'             => 2,
                                                                    'menu_id'      => '',
                                                                    'container_id'      => '',
                                                                    'container' => 'ul',
                                                                )
                                                            );
                                                            ?>
                        </div>
                        <div class="powered-by">
                            <span>powered by</span>
                            <ul>
                                <li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/imgs/ideias4apps.png" alt="ideias4apps" class="4apps"></a></li>
                                <li><a href="https://estudio86.com.br" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/imgs/e86.png" alt="Estudio86" class="e86"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>


<?php wp_footer(); ?>

</body>

</html>