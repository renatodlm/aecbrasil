<div class="bcn-custom">
    <?php
    if (function_exists('bcn_display')) {
        bcn_display();
    }
    ?>
</div>