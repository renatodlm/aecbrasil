<div class="topo-interna" 
class="parallax-window" data-parallax="scroll" data-position="center top" 
data-image-src="<?php the_post_thumbnail_url('topo-interna'); ?>">
    <div class="container">
        <div class="conteudo">
            <div class="titulo-topo"><h1><?php the_title(); ?></h1></div>
        </div>
    </div>
    <div class="overlay"></div>
</div>