<?php

/**
 * Template Name: Home
 *
 * The template page for home page
 *
 * @package estudio86
 * @since 1.0
 */

get_header('home'); ?>

<?php if (have_rows('banner_principal')) : ?>
  <div class="banner-principal">
    <?php while (have_rows('banner_principal')) : the_row();
      $texto = get_sub_field('texto');
      $bg = get_sub_field('imagem_de_fundo');
      $src = $bg['sizes']['banner-principal'];
      $imagem = get_sub_field('imagem');
      $src_2 = $imagem['sizes']['crop-512'];
    ?>
      <div class="bg-banner" style="background-image: url(<?php echo $src; ?>)">
        <div class="container">
          <div class="row d-flex align-items-end">
            <div class="coluna col-md-7 banner-text-container">
              <div class="conteudo">
                <h1><?php echo $texto; ?></h1>
              </div>
            </div>
            <div class="coluna col-md-5">
              <img class="banner-img" src="<?= $src_2; ?>" alt="<?= $imagem['alt']; ?>">
            </div>
          </div>
        </div>
        <div class="overlay"></div>
      </div>
    <?php endwhile; ?>
  </div>
<?php endif; ?>

<?php if (have_rows('video_em_destaque')) : ?>
  <section class="video-home">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="video-destaque">
            <div class="row d-flex justify-content-center">

              <?php while (have_rows('video_em_destaque')) : the_row();
                $video = get_sub_field('video');
                $botao = get_sub_field('botao');
                $miniatura = get_sub_field('miniatura');
                $miniatura_url = $miniatura['sizes']['crop-512'];
                preg_match('/src="(.+?)"/', $video, $matches_url);
                $src = $matches_url[1];
                preg_match('/embed(.*?)?feature/', $src, $matches_id);
                $id = $matches_id[1];
                $id = str_replace(str_split('?/'), '', $id);
                $video = preg_replace('~<iframe[^>]*\K(?=src)~i', 'data-', $video);
                $video = str_replace('youtube.com/embed/', 'youtube-nocookie.com/embed/', $video);
              ?>
                <div class="col-12">
                  <div class="titulo">
                    <h2><?php echo get_sub_field('titulo'); ?></h2>
                    <div class="linha"></div>
                  </div>
                </div>
                <div class="col-lg-12 coluna-video video-item">
                  <div class="ficha-before-video"></div>
                  <div class="video-thumb" <?php if ($miniatura) { ?>style="background-image: url(<?= $miniatura_url; ?>)" <?php } else { ?>style="background-image: url(https://img.youtube.com/vi/<?= $id; ?>/hqdefault.jpg)" <?php } ?>>
                    <div class="play-button">
                    </div>
                    <div class="overlay"></div>

                  </div>
                  <div class="video-embed">
                    <?= $video; ?>
                  </div>
                  <div class="ficha-after-video"></div>
                </div>
              <?php $n++;
              endwhile; ?>
            </div>
            <?php if ($botao) : ?>
              <a class="bt-link" href="<?php echo $botao['url']; ?>" target="<?php echo $botao['target']; ?>">
                <button class="btn-1">
                  <?php echo $botao['title']; ?>
                </button>
              </a>
            <?php endif ?>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php endif; ?>

<?php if (have_rows('conhecer_os_planos')) : ?>
  <section>
    <div class="container">
      <div class="row posts-items d-flex align-items-center">
        <?php while (have_rows('conhecer_os_planos')) : the_row();
          $imagem = get_sub_field('imagem');
          $imagem_src = $imagem['sizes']['crop-512'];
          $titulo = get_sub_field('titulo');
          $texto = get_sub_field('texto');
          $botao = get_sub_field('botao');
        ?>

          <div class="col-md-6 order-md-1 order-2">
            <img class="img-fluid" src="<?php echo $imagem_src;  ?>" alt="<?= $imagem['alt']; ?>">
          </div>
          <div class="col-md-6 order-md-2 order-1">
            <h4 class="conhecer-planos-titulo"><?php echo $titulo; ?></h4>
            <p><?php echo $texto; ?></p>
            <?php if ($botao) : ?>
              <div class="d-md-block d-none">
                <a class="bt-link" href="<?php echo $botao['url']; ?>" target="<?php echo $botao['target']; ?>">
                  <button class="btn-1">
                    <?php echo $botao['title']; ?>
                  </button>
                </a>
              </div>
            <?php endif ?>
          </div>
          <?php if ($botao) : ?>
            <div class="d-md-none col-12 d-flex order-3 botao-mobile">
              <a class="bt-link" href="<?php echo $botao['url']; ?>" target="<?php echo $botao['target']; ?>">
                <button class="btn-1">
                  <?php echo $botao['title']; ?>
                </button>
              </a>
            </div>
          <?php endif ?>
        <?php endwhile; ?>
      </div>
    </div>
  </section>
  <section class="pt-md-0"></section>
<?php endif; ?>

<?php if (have_rows('afiliados')) : ?>
  <section class="afiliados-home">
    <div class="container">
      <div class="ficha-before-afiliados"></div>
      <h2 class="afiliados-titulo">Afiliados GoodPoker</h2>
      <div class="afiliados-slide">
        <?php while (have_rows('afiliados')) : the_row();
          $foto = get_sub_field('foto');
          $foto_src = $foto['sizes']['crop-512'];
          $nome = get_sub_field('nome');
          $resumo = get_sub_field('resumo');
        ?>
          <div class="afiliados-slide-item">
            <div class="afiliado-item">
              <img class="afiliado-img" src="<?php echo $foto_src; ?>" alt="<?= $imagem['alt']; ?>">
              <div class="afiliado-info">
                <h3 class="afiliado-name"><?php echo $nome; ?></h3>
                <p class="afiliado-resume"><?php echo $resumo; ?></p>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
      <div class="ficha-after-afiliados"></div>
    </div>
  </section>
<?php endif; ?>

<?php if (have_rows('depoimentos')) : ?>
  <section class="depoimentos">
    <div class="container">
      <h3 class="depoimentos-titulo">#GoodPokerPlayers</h3>
      <div class="depoimentos-slide">
        <?php while (have_rows('depoimentos')) : the_row();

          $foto = get_sub_field('foto');
          $foto_src = $foto['sizes']['crop-512'];
          $nome = get_sub_field('nome');
          $texto = get_sub_field('texto');
          $resumo = get_sub_field('resumo');

        ?>
          <div class="depoimento-item shadow m-3">
            <div class="depoimento-content">
              <div class="depoimento-aspas"></div>
              <div class="depoimentos-texto">
                <?php echo $texto; ?>
              </div>
            </div>
            <div class="depoimento-author">
              <div class="author-img" style="background-image: url(<?php echo $foto_src; ?>);">
              </div>
              <div class="author-infos">
                <h5 class="author-name">
                  <?php echo $nome; ?>
                </h5>
                <p class="author-resume">
                  <?php echo $resumo; ?>
                </p>
              </div>
            </div>
          </div>

        <?php endwhile; ?>
      </div>
    </div>
  </section>
  <section class="pt-0"></section>
<?php endif; ?>

<?php if (have_rows('sobre')) : ?>
  <section class="sobre-home">
    <div class="container">
      <div class="row posts-items d-flex align-items-center">
        <?php while (have_rows('sobre')) : the_row();
          $imagem = get_sub_field('imagem');
          $imagem_src = $imagem['sizes']['crop-512'];
          $titulo = get_sub_field('titulo');
          $texto = get_sub_field('texto');
          $botao = get_sub_field('botao');
        ?>

          <div class="col-md-6 order-2 order-md-1">
            <h4 class="sobre-titulo d-md-block d-none"><?php echo $titulo; ?></h4>
            <p class="sobre-text"><?php echo $texto; ?></p>
            <div class="text-md-left text-center">
              <?php if ($botao) : ?>
                <a class="bt-link" href="<?php echo $botao['url']; ?>" target="<?php echo $botao['target']; ?>">
                  <button class="btn-1">
                    <?php echo $botao['title']; ?>
                  </button>
                </a>
              <?php endif ?>
            </div>
          </div>
          <div class="col-md-6 order-1 order-md-2">
            <h4 class="sobre-titulo d-md-none d-block"><?php echo $titulo; ?></h4>
            <img class="img-fluid" src="<?php echo $imagem_src;  ?>" alt="<?= $imagem['alt']; ?>">
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </section>
<?php endif; ?>

<section class="pt-0"></section>

<?php
get_footer(); ?>