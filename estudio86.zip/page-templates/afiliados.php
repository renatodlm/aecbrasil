<?php

/**
 * Template Name: Afiliados
 *
 * The template page for afiliados
 *
 * @package estudio86
 * @since 1.0
 */

get_header(); ?>

<section class="afiliados">
  <div class="container">
    <div class="row">
      <div class="afiliados-header col-12 d-flex align-items-center justify-content-between">
        <h1 class="afiliados-title">
          Programa de Afiliados GoodPoker
        </h1>
        <?php get_template_part('template-parts/content', 'breadcrumb'); ?>
      </div>
      <div class="col-12">
        <p>Junte-se ao programa de afiliados GoodPoker e receba recompensas por novos clientes e upgrades de plano.
          <br><br>
          O processo é simples: você usa a plataforma para fazer review de mãos com o seu público, divulga seu código exclusivo e orienta a audiência a utilizá-lo no ato da compra.
          <br><br>
          A cada conversão, você recebe 10% do valor da assinatura.<br>
          Quer fazer parte? Preencha o formulário abaixo e entraremos em contato:
        </p>
      </div>
      <div class="col-12">

        <?php echo do_shortcode('[contact-form-7 id="179" title="Programa de Afiliados GoodPoker"]'); ?>

      </div>
    </div>
  </div>
</section>

<section class="bonus">
  <div class="container">
    <h3 class="bonus-title">
      Bônus por Aquisição
    </h3>
    <p>A cada 10 assinaturas em cada plano, você recebe 1 ponto que pode ser trocado por um bônus.
      <br>
      Além do valor de comissão padrão (10%), seus pontos extras seguem a tabela abaixo:
    </p>
    <div class="bonus-container-pc">
      <ul class="bonus-ul plans">
        <li class="bonus-li-header">Plano</li>
        <li class="bonus-li-list">Pré-flop</li>
        <li class="bonus-li-list">Flush</li>
        <li class="bonus-li-list">Full House</li>
        <li class="bonus-li-list">All-In</li>
      </ul>
      <ul class="bonus-ul bonus">
        <li class="bonus-li-header">Valor do Plano (U$)</li>
        <li class="bonus-li-list">U$ 60,00</li>
        <li class="bonus-li-list">U$ 72,00</li>
        <li class="bonus-li-list">U$ 84,00</li>
        <li class="bonus-li-list">U$ 96,00</li>
      </ul>
      <ul class="bonus-ul bonus">
        <li class="bonus-li-header">Valor do ponto a cada
          10 assinaturas (U$)</li>
        <li class="bonus-li-list">U$ 1,00</li>
        <li class="bonus-li-list">U$ 2,00</li>
        <li class="bonus-li-list">U$ 3,00</li>
        <li class="bonus-li-list">U$ 4,00</li>
      </ul>
    </div>
    <div class="bonus-container-mobile">
      <ul class="bonus-ul plans">
        <li class="bonus-li-header">Pré-flop</li>
        <li class="bonus-li-list">U$ 60,00</li>
        <li class="bonus-li-header-each">Valor do ponto a cada
          10 assinaturas (U$)</li>
          <li class="bonus-li-list">U$ 1,00</li>
      </ul>
      <ul class="bonus-ul plans">
        <li class="bonus-li-header">Flush</li>
        <li class="bonus-li-list">U$ 72,00</li>
        <li class="bonus-li-header-each">Valor do ponto a cada
          10 assinaturas (U$)</li>
          <li class="bonus-li-list">U$ 2,00</li>
      </ul>
      <ul class="bonus-ul plans">
        <li class="bonus-li-header">Full House</li>
        <li class="bonus-li-list">U$ 84,00</li>
        <li class="bonus-li-header-each">Valor do ponto a cada
          10 assinaturas (U$)</li>
          <li class="bonus-li-list">U$ 3,00</li>
      </ul>
      <ul class="bonus-ul plans">
        <li class="bonus-li-header">All-In</li>
        <li class="bonus-li-list">U$ 96,00</li>
        <li class="bonus-li-header-each">Valor do ponto a cada
          10 assinaturas (U$)</li>
          <li class="bonus-li-list">U$ 4,00</li>
      </ul>

    </div>
    <p>O percentual de comissão e a tabela de bonificação podem ser alterados a qualquer momento.<br><br>
      Em caso de dúvidas, entre em contato através do Suporte utilizando a categoria Programa de Afiliados.
    </p>
  </div>
</section>
<section class="pt-0"></section>

<?php get_footer(); ?>