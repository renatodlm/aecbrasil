<?php

// Sizes
add_image_size('article-thumbnail', 700, 400, true);
add_image_size('post-thumbnail', 1200, 500, true);
add_image_size('topo-interna', 1920, 450, true);
add_image_size('banner-principal', 1920, 650, true);
add_image_size('galeria-lg', 800, 800, false);
add_image_size('galeria-sm', 375, 375, false);
add_image_size('crop-512', 512, 512, false);
