Tema base para criação de sites com ACF

Passos para instalação do tema no ambiente de desenvolvimento:

	1. Copiar pasta estudio86 para dentro de wp-content/themes/
	2. Utilizar o comando na pasta para instalar suas dependências com node:
		a. npm install gulp
	3. Ativar gulp para compilar o SCSS
		a. Gulp
	4. Instalar todos os plugins obrigatórios do tema no painel wordpress > Begin installing plugins
	5. Inserir logo e favicon do site pelo menu wordpress Aparência>Personalizar>Identidade do Site
Preencher informações no painel Opções do Tema no menu wordpress